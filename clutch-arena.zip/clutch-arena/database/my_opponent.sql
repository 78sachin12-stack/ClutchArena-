-- Run this ONCE in Supabase > SQL Editor on the Clutch Arena project.
-- Gives each paid player the game UID of the other paid player in their slot pair
-- (slots 1 and 2, slots 3 and 4, and so on) so they can make their own custom room.
--
-- ASSUMPTIONS (the website code I have does not show the table structure):
--   public.registrations has: id, tournament_id, user_id (auth user), slot, captain, uid, payment_status
--   public.tournaments has:   id, name, starts_at
-- If any name differs, or the call errors, send me the structure of both tables
-- and I will fix this.

create or replace function public.my_opponent(p_tournament text, p_starts timestamptz)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  me record;
  opp record;
begin
  if auth.uid() is null then
    return null;
  end if;

  select r.id, r.slot::int as slot, r.tournament_id into me
  from public.registrations r
  join public.tournaments t on t.id = r.tournament_id
  where r.user_id = auth.uid()
    and t.name = p_tournament
    and t.starts_at = p_starts
    and r.payment_status = 'paid'
  order by r.id desc
  limit 1;

  if not found or me.slot is null then
    return null;
  end if;

  select r.captain, r.uid into opp
  from public.registrations r
  where r.tournament_id = me.tournament_id
    and r.payment_status = 'paid'
    and r.id <> me.id
    and ((r.slot::int - 1) / 2) = ((me.slot - 1) / 2)
  limit 1;

  if not found then
    return jsonb_build_object('waiting', true);
  end if;

  return jsonb_build_object('waiting', false, 'name', opp.captain, 'uid', opp.uid);
end;
$$;

revoke all on function public.my_opponent(text, timestamptz) from public, anon;
grant execute on function public.my_opponent(text, timestamptz) to authenticated;
