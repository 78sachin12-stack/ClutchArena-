-- Run this ONCE in Supabase > SQL Editor on the Clutch Arena project.
-- Lets the admin panel save the leaderboard. Only admins can call it.
-- Assumes public.leaderboard has columns: game, fmt, name, matches, placement, kills
-- (the website already reads these). If the table has other required columns
-- or is a view, send me its structure and I will adjust this.

create or replace function public.admin_set_leaderboard(p_game text, p_fmt text, p_rows jsonb)
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  n integer := 0;
  r jsonb;
begin
  if not coalesce(public.is_admin(), false) then
    raise exception 'not admin';
  end if;
  if p_game not in ('BGMI', 'Free Fire') or p_fmt not in ('Solo', 'Duo', 'Squad') then
    raise exception 'bad game or format';
  end if;

  delete from public.leaderboard where game = p_game and fmt = p_fmt;

  for r in select * from jsonb_array_elements(coalesce(p_rows, '[]'::jsonb)) loop
    insert into public.leaderboard (game, fmt, name, matches, placement, kills)
    values (
      p_game, p_fmt,
      left(trim(r->>'name'), 40),
      greatest(0, coalesce((r->>'matches')::int, 0)),
      greatest(0, coalesce((r->>'placement')::int, 0)),
      greatest(0, coalesce((r->>'kills')::int, 0))
    );
    n := n + 1;
  end loop;
  return n;
end;
$$;

revoke all on function public.admin_set_leaderboard(text, text, jsonb) from public, anon;
grant execute on function public.admin_set_leaderboard(text, text, jsonb) to authenticated;
