-- Run this ONCE in Supabase > SQL Editor on the Clutch Arena project.
-- Saves the prize UPI ID a player types when booking (the admin panel already reads payout_upi).
--
-- ASSUMPTIONS: public.registrations has columns id, user_id (auth user) and payout_upi.
-- If payout_upi lives somewhere else (for example a profiles table), or the call errors,
-- send me the structure of the registrations table and I will fix this.
-- Until it is run, booking still works; players just see "your UPI ID was not saved".

create or replace function public.set_payout_upi(p_reg bigint, p_upi text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is null then
    raise exception 'login required';
  end if;
  if p_upi !~ '^[A-Za-z0-9._-]{3,60}@[A-Za-z]{2,30}$' then
    raise exception 'bad upi id';
  end if;
  update public.registrations
     set payout_upi = p_upi
   where id = p_reg
     and user_id = auth.uid();
  if not found then
    raise exception 'registration not found';
  end if;
end;
$$;

revoke all on function public.set_payout_upi(bigint, text) from public, anon;
grant execute on function public.set_payout_upi(bigint, text) to authenticated;
